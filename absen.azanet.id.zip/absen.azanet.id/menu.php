<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a href="#" class="navbar-brand">ABSENSI</a>
		</div>
		<ul class="nav navbar-nav">
			<li> <a href="index.php"> Halaman Awal</a> </li>
			<li> <a href="datakaryawan.php"> Data Siswa </a> </li>
			<li> <a href="absensi.php"> Rekapitulasi Absensi </a> </li>
			<li> <a href="scan.php"> Scan Kartu </a> </li>
		</ul>
	</div>
</nav>