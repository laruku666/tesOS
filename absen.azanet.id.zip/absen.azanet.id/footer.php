<div class="footer" style="text-align: center">
	 <br>
	<strong>SMK NEGERI 15 KOTA BEKASI</strong>
</div>