<?php
	//urutan = server, userdb, passdb, namadb
	$konek = mysqli_connect("localhost", "azanetid", "08561821327Hydodie", "azanetid_absenrfid");
?>