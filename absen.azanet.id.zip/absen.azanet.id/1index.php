<!DOCTYPE html>
<html>
<head>
	<?php include "header.php"; ?>
	<title>Menu Utama</title>
</head>
<body>
	<?php include "menu.php"; ?>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 10%; text-align: center">
		<h1>
			Selamat Datang <br>
			SISTEM ABSENSI Siswa <br>
			BERBASIS KARTU RFID
		</h1>
	</div>

	<?php include "footer.php"; ?>
</body>
</html>